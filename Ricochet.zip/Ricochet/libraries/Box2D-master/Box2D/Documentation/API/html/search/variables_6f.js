var searchData=
[
  ['other',['other',['../structb2_contact_edge.html#a69015fc22e064eac04ed74f27a13ae78',1,'b2ContactEdge::other()'],['../structb2_joint_edge.html#a64aef21fb91211871de8796baecccb95',1,'b2JointEdge::other()']]]
];
